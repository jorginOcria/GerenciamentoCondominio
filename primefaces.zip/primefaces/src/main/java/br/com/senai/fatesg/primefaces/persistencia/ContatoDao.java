package br.com.senai.fatesg.primefaces.persistencia;

import br.com.ambientinformatica.jpa.persistencia.Persistencia;
import br.com.senai.fatesg.primefaces.entidade.Contato;

public interface ContatoDao extends Persistencia<Contato>{

}
