package br.com.senai.fatesg.primefaces.entidade;

public enum EnumPapelUsuario {

   ADMIN,
   
   USUARIO;
   
}
