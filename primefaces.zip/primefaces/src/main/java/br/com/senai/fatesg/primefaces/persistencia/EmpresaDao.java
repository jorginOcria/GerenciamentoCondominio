package br.com.senai.fatesg.primefaces.persistencia;

import br.com.ambientinformatica.jpa.persistencia.Persistencia;
import br.com.senai.fatesg.primefaces.entidade.Empresa;

public interface EmpresaDao extends Persistencia<Empresa> {

}
