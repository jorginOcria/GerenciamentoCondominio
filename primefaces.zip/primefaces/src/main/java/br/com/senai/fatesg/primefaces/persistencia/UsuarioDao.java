package br.com.senai.fatesg.primefaces.persistencia;

import br.com.senai.fatesg.primefaces.entidade.Usuario;
import br.com.ambientinformatica.jpa.persistencia.Persistencia;

public interface UsuarioDao extends Persistencia<Usuario>{

}
